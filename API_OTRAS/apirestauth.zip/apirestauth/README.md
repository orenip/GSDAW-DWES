# apirestauth

Proyecto que implementa una API REST con autentificación mediante token. El lenguaje utilizado es PHP y no se ha utilizado ningún framework de desarrollo.
