# apirestcrud

Este proyecto es una API REST que realiza las operaciones CRUD sobre una tabla llamada "player" y que almacena las estadísticas de jugadores de baloncesto.

Está desarrollado en PHP sin usar ningún framework, simplemente separando la lógica en diferentes clases y factorizando la conexión a la base de datos.

En la carpeta "bbdd" se encuentra el esquema de base de datos para utilizar la api.
